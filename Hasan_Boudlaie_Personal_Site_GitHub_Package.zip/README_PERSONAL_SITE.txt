HASAN BOUDLAIE PERSONAL WEBSITE — GitHub Pages package

Same workflow used for Kish Ports & Airports:
1. Open https://github.com/hassnboudlaie/afra-tejarat-mad
2. Add file → Upload files
3. Upload hasan-boudlaie.html
4. Commit directly to main → Commit changes
5. Public URL: https://hassnboudlaie.github.io/afra-tejarat-mad/hasan-boudlaie.html

The HTML is self-contained: personal photos are embedded in the file, so no separate image upload is required.
